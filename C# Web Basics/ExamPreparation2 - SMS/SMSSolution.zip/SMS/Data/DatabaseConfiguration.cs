﻿namespace SMS.Data
{
    public class DatabaseConfiguration
    {
        // ReSharper disable once InconsistentNaming
        public const string ConnectionString =
            @"Server=.;Database=Sms;User Id = sa; Password=SoftUn!2021;";
    }
}
