﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Models
{
    public class CartViewModel
    {
        public string ProductName { get; set; }

        public string ProductPrice { get; set; }
    }
}
