﻿namespace AquaShop.Models.Decorations
{
    public class Plant : Decoration
    {
        public Plant(int comfort, decimal price) 
            : base(5, 10)
        {
        }
    }
}
