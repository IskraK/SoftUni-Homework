﻿namespace AquaShop.Models.Decorations
{
    public class Ornament : Decoration
    {
        public Ornament(int comfort, decimal price) 
            : base(1, 5)
        {
        }
    }
}
