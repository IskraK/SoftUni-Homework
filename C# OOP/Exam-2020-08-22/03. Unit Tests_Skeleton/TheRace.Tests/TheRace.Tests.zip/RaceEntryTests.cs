using NUnit.Framework;
using System;

namespace TheRace.Tests
{
    public class RaceEntryTests
    {
        private RaceEntry raceEntry;

        [SetUp]
        public void Setup()
        {
            raceEntry = new RaceEntry();
        }

        [Test]
        public void AddDriver_ThrowsException_WhenDrivewrIsNull()
        {
            Assert.Throws<InvalidOperationException>(() => raceEntry.AddDriver(null));
        }

        [Test]
        public void AddDriver_ThrowsException_WhenDriverExists()
        {
            UnitCar car = new UnitCar("Model", 100, 500);
            UnitDriver driver = new UnitDriver("Name", car);
            raceEntry.AddDriver(driver);
            Assert.Throws<InvalidOperationException>(() => raceEntry.AddDriver(driver));
        }

        [Test]
        public void AddDriver_IncreasesCount_WhenDriverIsValid()
        {
            UnitCar car = new UnitCar("Model", 100, 500);
            UnitDriver driver = new UnitDriver("Name", car);
            raceEntry.AddDriver(driver);
            Assert.That(raceEntry.Counter, Is.EqualTo(1));
        }

        [Test]
        public void CalculateAverageHorsePower_ThrowsException_WhenDriversAreLessThanMinimum()
        {
            UnitCar car = new UnitCar("Model", 100, 500);
            UnitDriver driver = new UnitDriver("Name", car);
            raceEntry.AddDriver(driver);
            Assert.Throws<InvalidOperationException>(() => raceEntry.CalculateAverageHorsePower());
        }

        [Test]
        public void CalculateAverageHorsePower_ReturnsAverageHorsePower_WhenDriversAreMoreThanMinimum()
        {
            UnitCar car = new UnitCar("Model", 100, 500);
            UnitDriver driver = new UnitDriver("Name", car);
            raceEntry.AddDriver(driver);
            UnitCar car2 = new UnitCar("Model2", 200, 500);
            UnitDriver driver2 = new UnitDriver("Name2", car2);
            raceEntry.AddDriver(driver2);
            double expectedAvgHorsePower=(driver.Car.HorsePower+driver2.Car.HorsePower)/ 2;
            Assert.That(raceEntry.CalculateAverageHorsePower(),Is.EqualTo(expectedAvgHorsePower));
        }
    }
}