﻿namespace Easter.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}