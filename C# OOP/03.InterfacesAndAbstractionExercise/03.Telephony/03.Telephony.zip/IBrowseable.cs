﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.Telephony
{
    public interface IBrowseable
    {
        void Browse(string site);
    }
}
