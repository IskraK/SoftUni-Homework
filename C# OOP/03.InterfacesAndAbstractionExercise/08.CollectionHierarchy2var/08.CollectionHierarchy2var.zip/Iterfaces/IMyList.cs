﻿namespace _08.CollectionHierarchy2var.Iterfaces
{
    public interface IMyList:IAddRemoveCollection
    {
        int Used { get; }
    }
}
