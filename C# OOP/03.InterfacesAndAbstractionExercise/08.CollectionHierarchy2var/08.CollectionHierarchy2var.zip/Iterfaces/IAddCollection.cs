﻿namespace _08.CollectionHierarchy2var.Iterfaces
{
    public interface IAddCollection
    {
        int Add(string element);
    }
}
