﻿namespace _08.CollectionHierarchy2var.Iterfaces
{
    public interface IAddRemoveCollection:IAddCollection
    {
        string Remove();
    }
}
