﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_StudentSystem.Data.Enums
{
    public enum ContentType
    {
        Application=1, 
        Pdf, 
        Zip
    }
}
