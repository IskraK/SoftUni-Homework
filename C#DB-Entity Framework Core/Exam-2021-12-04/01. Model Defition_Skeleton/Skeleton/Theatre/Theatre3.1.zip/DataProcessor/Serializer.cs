﻿namespace Theatre.DataProcessor
{
    using Newtonsoft.Json;
    using System;
    using System.Linq;
    using Theatre.Data;

    public class Serializer
    {
        public static string ExportTheatres(TheatreContext context, int numbersOfHalls)
        {
            var theatres = context.Theatres.ToList()
                .Where(t => t.NumberOfHalls >= numbersOfHalls && t.Tickets.Count >= 20)
                .Select(t => new
                {
                    Name = t.Name,
                    Halls = t.NumberOfHalls,
                    TotalIncome = t.Tickets.Where(tk => tk.RowNumber >= 1 && tk.RowNumber <= 5).Sum(tk => tk.Price),
                    Tickets = t.Tickets
                    .Where(tk => tk.RowNumber >= 1 && tk.RowNumber <= 5)
                    .Select(tk => new
                    {
                        Price = tk.Price,
                        RowNumber = tk.RowNumber
                    }).ToList()
                    .OrderByDescending(tk => tk.Price)
                }).ToList()
                .OrderByDescending(t => t.Halls)
                .ThenBy(t => t.Name)
                .ToList();

            string theatresJson = JsonConvert.SerializeObject(theatres, Formatting.Indented);

            return theatresJson;
        }

        public static string ExportPlays(TheatreContext context, double rating)
        {
            throw new NotImplementedException();
        }
    }
}

//The given method in the project’s skeleton receives a number representing the number of halls. Export all theaters where the hall's count is bigger or equal to the given and have 20 or more tickets available. For each theater, export its Name, Halls, TotalIncome of tickets which are between the first and fifth row inclusively, and Tickets. For each ticket (between first and fifth row inclusively), export its price, and the row number. Order the theaters by the number of halls descending, then by name (ascending). Order the tickets by price descending

//[
//  {
//    "Name": "Capitol Theatre Building",
//    "Halls": 10,
//    "TotalIncome": 860.02,
//    "Tickets": [
//      {
//        "Price": 93.48,
//        "RowNumber": 3
//      },
//      {
//    "Price": 93.41,
//        "RowNumber": 1
//      },
//      {
//    "Price": 86.21,
//        "RowNumber": 5
//      },
