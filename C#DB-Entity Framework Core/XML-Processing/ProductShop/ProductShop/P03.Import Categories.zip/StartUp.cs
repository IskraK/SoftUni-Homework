﻿using ProductShop.Data;
using ProductShop.Dtos.Import;
using ProductShop.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            ProductShopContext context = new ProductShopContext();

            //context.Database.EnsureDeleted();
            //context.Database.EnsureCreated();

            //Problem 01. Import Users
            //string inputXml = File.ReadAllText("../../../Datasets/users.xml");
            //string result = ImportUsers(context, inputXml);
            //Console.WriteLine(result);

            //Problem 02. Import Products
            //string inputXml = File.ReadAllText("../../../Datasets/products.xml");
            //string result = ImportProducts(context, inputXml);
            //Console.WriteLine(result);

            //Problem 03. Import Categories
            string inputXml = File.ReadAllText("../../../Datasets/categories.xml");
            string result = ImportCategories(context, inputXml);
            Console.WriteLine(result);
        }

        //Query 1. Import Users
        public static string ImportUsers(ProductShopContext context, string inputXml)
        {
            XmlRootAttribute xmlRoot = new XmlRootAttribute("Users");
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(ImportUsersDto[]), xmlRoot);

            using StringReader stringReader = new StringReader(inputXml);

            ImportUsersDto[] dtos = (ImportUsersDto[])xmlSerializer.Deserialize(stringReader);

            ICollection<User> users = new HashSet<User>();

            foreach (var userDto in dtos)
            {
                User user = new User()
                {
                    FirstName = userDto.FirstName,
                    LastName = userDto.LastName,
                    Age = userDto.Age
                };

                users.Add(user);
            }

            context.Users.AddRange(users);
            context.SaveChanges();

            return $"Successfully imported {users.Count}";
        }

        //Problem 02. Import Products
        public static string ImportProducts(ProductShopContext context, string inputXml)
        {
            XmlRootAttribute xmlRoot = new XmlRootAttribute("Products");
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(ImportProductDto[]),xmlRoot);

            using StringReader stringReader = new StringReader(inputXml);

            ImportProductDto[] dtos = (ImportProductDto [])xmlSerializer.Deserialize(stringReader);
            ICollection<Product> products = new HashSet<Product>();

            foreach (var productDto in dtos)
            {
                Product product = new Product()
                {
                    Name = productDto.Name,
                    Price = decimal.Parse(productDto.Price),
                    SellerId = productDto.SellerId,
                    BuyerId = productDto.BuyerId
                };

                products.Add(product);
            }

            context.Products.AddRange(products);
            context.SaveChanges();

            return $"Successfully imported {products.Count}";
        }

        //Problem 03. Import Categories
        public static string ImportCategories(ProductShopContext context, string inputXml)
        {
            XmlRootAttribute xmlRoot = new XmlRootAttribute("Categories");
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(ImportCategoryDto[]), xmlRoot);

            using StringReader stringReader = new StringReader(inputXml);

            ImportCategoryDto[] dtos = (ImportCategoryDto[])xmlSerializer.Deserialize(stringReader);
            ICollection<Category> categories = new HashSet<Category>();

            foreach (var categoryDto in dtos)
            {
                //Category category = context.Categories.Find(categoryDto.Name);

                //if (category == null)
                //{
                //    continue;
                //}

                Category c = new Category()
                {
                    Name = categoryDto.Name
                };

                categories.Add(c);
            }

            context.Categories.AddRange(categories);
            context.SaveChanges();

            return $"Successfully imported {categories.Count}";
        }
    }
}