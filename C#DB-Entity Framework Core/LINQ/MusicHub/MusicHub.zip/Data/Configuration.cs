﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public const string Connection_String = @"Server=.;Database=MusicHub;Integrated Security=true;";
    }
}
