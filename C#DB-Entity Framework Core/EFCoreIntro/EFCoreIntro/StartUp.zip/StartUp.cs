﻿using SoftUni.Data;
using System;

namespace SoftUni
{
    class StartUp
    {
        static void Main(string[] args)
        {
            var context = new SoftUniContext();
        }
    }
}
