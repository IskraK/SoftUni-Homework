﻿using SoftUni.Data;
using System;
using System.Linq;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var context = new SoftUniContext();
            string result = GetEmployeesWithSalaryOver50000(context);
            Console.WriteLine(result);
        }


        //3.Employees Full Information
        public static string GetEmployeesFullInformation(SoftUniContext softUniContext)
        {
            StringBuilder sb = new StringBuilder();

            var result = softUniContext.Employees
                .OrderBy(e => e.EmployeeId)
                .Select(e => sb.AppendLine($"{e.FirstName} {e.LastName} {e.MiddleName} {e.JobTitle} {e.Salary:F2}"))
                .ToArray();

            return sb.ToString().TrimEnd();
        }


        //4.Employees with Salary Over 50 000
        public static string GetEmployeesWithSalaryOver50000(SoftUniContext softUniContext)
        {
            StringBuilder sb = new StringBuilder();
            var employees = softUniContext.Employees
                .Where(e => e.Salary > 50000)
                .OrderBy(e => e.FirstName)
                .Select(e => new { e.FirstName, e.Salary })
                .ToArray();

            foreach (var employee in employees)
            {
                sb.AppendLine($"{employee.FirstName} - {employee.Salary:F2}");
            }

            return sb.ToString().TrimEnd();
        }
    }
}
