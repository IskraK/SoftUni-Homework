﻿namespace VaporStore.DataProcessor
{
	using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Globalization;
    using System.Linq;
    using System.Text;
    using Data;
    using Newtonsoft.Json;
    using VaporStore.Data.Models;
    using VaporStore.Data.Models.Enums;
    using VaporStore.DataProcessor.Dto.Import;

    public static class Deserializer
	{
		public static string ImportGames(VaporStoreDbContext context, string jsonString)
		{
			StringBuilder sb = new StringBuilder();

			GameImportDto[] gameDtos = JsonConvert.DeserializeObject<GameImportDto[]>(jsonString);
			List<Game> games = new List<Game>();
			List<Developer> developers = new List<Developer>();
			List<Genre> genres = new List<Genre>();
			List<Tag> tags = new List<Tag>();

            foreach (var gameDto in gameDtos)
            {
                if (!IsValid(gameDto))
                {
					sb.AppendLine("Invalid Data");
					continue;
                }

				bool isValidReleaseDate = DateTime.TryParseExact(gameDto.ReleaseDate, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime releaseDate);

                if (!isValidReleaseDate)
                {
					sb.AppendLine("Invalid Data");
					continue;
				}

				Game game = new Game()
				{
					Name = gameDto.Name,
					Price = gameDto.Price,
					ReleaseDate = releaseDate
				};

				Developer developer = developers.FirstOrDefault(d => d.Name == gameDto.Developer);
                if (developer is null)
                {
					developer = new Developer() { Name = gameDto.Developer };
					developers.Add(developer);
                }

				game.Developer = developer;

				Genre genre = genres.FirstOrDefault(g => g.Name == gameDto.Genre);
                if (genre is null)
                {
					genre = new Genre() { Name = gameDto.Genre };
					genres.Add(genre);
                }

				game.Genre = genre;

                foreach (var tagDto in gameDto.Tags)
                {
					Tag tag = tags.FirstOrDefault(t => t.Name == tagDto);
                    if (tag is null)
                    {
						tag = new Tag() { Name = tagDto };
						tags.Add(tag);
                    }

					game.GameTags.Add(new GameTag() { Tag = tag });
                }

				games.Add(game);
				sb.AppendLine($"Added {gameDto.Name} ({gameDto.Genre}) with {gameDto.Tags.Length} tags");
			}

			context.Games.AddRange(games);
			context.SaveChanges();

			return sb.ToString().TrimEnd();
		}

		public static string ImportUsers(VaporStoreDbContext context, string jsonString)
		{
			StringBuilder sb = new StringBuilder();

			UserImportDto[] userDtos = JsonConvert.DeserializeObject<UserImportDto[]>(jsonString);
			List<User> users = new List<User>();

            foreach (var userDto in userDtos)
            {
                if (!IsValid(userDto) || !userDto.Cards.All(IsValid))
                {
					sb.AppendLine("Invalid Data");
					continue;
				}

				User user = new User()
				{
					Username = userDto.Username,
					FullName = userDto.FullName,
					Age = userDto.Age,
					Email = userDto.Email,
					Cards = userDto.Cards.Select(c => new Card()
					{
						Number = c.Number,
						Cvc = c.Cvc,
						Type = c.Type.Value
					})
					.ToList()
				};

				users.Add(user);
				sb.AppendLine($"Imported {userDto.Username} with {userDto.Cards.Length} cards");
            }

			context.Users.AddRange(users);
			context.SaveChanges();

			return sb.ToString().TrimEnd();
		}

		public static string ImportPurchases(VaporStoreDbContext context, string xmlString)
		{
			throw new NotImplementedException();
		}

		private static bool IsValid(object dto)
		{
			var validationContext = new ValidationContext(dto);
			var validationResult = new List<ValidationResult>();

			return Validator.TryValidateObject(dto, validationContext, validationResult, true);
		}
	}
}